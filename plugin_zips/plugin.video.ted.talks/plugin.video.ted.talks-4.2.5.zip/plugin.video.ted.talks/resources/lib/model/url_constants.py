URLTED = 'http://www.ted.com'
URLTHEMES = URLTED + '/themes'
URLSEARCH = URLTED + '/search?cat=talks&q=%s&page=%s'
