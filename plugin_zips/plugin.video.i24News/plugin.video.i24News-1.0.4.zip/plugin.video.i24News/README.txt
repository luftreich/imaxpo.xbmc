plugin.video.i24News
================


XBMC Addon for i24News

Version 1.0.4 Updated for website changes

Version 1.0.3 Updated for website changes, added next page for shows

version 1.0.2 updated for website changes

version 1.0.1 initial release
