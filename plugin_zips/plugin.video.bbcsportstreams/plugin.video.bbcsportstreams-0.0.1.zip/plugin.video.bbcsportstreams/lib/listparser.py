#
# Provides a simple and very quick way to parse list feeds
#

import re, sys
import logging

logging.basicConfig(
    stream=sys.stdout,
    level=logging.DEBUG,
    format='listparser.py: %(levelname)4s %(message)s',)

def xmlunescape(data):
    data = data.replace('&amp;', '&')
    data = data.replace('&gt;', '>')
    data = data.replace('&lt;', '<')
    return data

class listentry(object):
     def __init__(self, title=None, id=None, updated=None, summary=None, categories=None, opid=None):
         self.title      = title
         self.id         = id
	 self.opid	 = opid #the feed has more than one pid for live events, the version pid which you seem to need to play the thing and the regular pid which is useful for images
         self.updated    = updated
         self.summary    = summary
         self.categories = categories

class listentries(object):
     def __init__(self):
         self.entries = []
                  
def parse(xmlSource):  
    try:
        encoding = re.findall( "<\?xml version=\"[^\"]*\" encoding=\"([^\"]*)\"\?>", xmlSource )[ 0 ]
    except: return None
    elist=listentries()
    # gather all list entries 
    entriesSrc = re.findall( "<entry>(.*?)</entry>", xmlSource, re.DOTALL)
    datematch = re.compile(':\s+([0-9]+)/([0-9]+)/([0-9]{4})')
    
    # enumerate thru the element list and gather info
    for entrySrc in entriesSrc:
        entry={}
        title   = re.findall( "<title[^>]*>(.*?)</title>", entrySrc, re.DOTALL )[0]
        id      = re.findall( "<id[^>]*>(.*?)</id>", entrySrc, re.DOTALL )[0]
        updated = re.findall( "<updated[^>]*>(.*?)</updated>", entrySrc, re.DOTALL )[0]
        summary = re.findall( "<content[^>]*>(.*?)</content>", entrySrc, re.DOTALL )[0].splitlines()[-3]
        categories = re.findall( "<category[^>]*term=\"(.*?)\"[^>]*>", entrySrc, re.DOTALL )

        match = datematch.search(title)
        if match:
            # if the title contains a data at the end use that as the updated date YYYY-MM-DD
            updated = "%s-%s-%s" % ( match.group(3), match.group(2), match.group(1)  )
                    
        e_categories=[]
        for c in categories: e_categories.append(xmlunescape(c))        
        elist.entries.append(listentry(xmlunescape(title), xmlunescape(id), xmlunescape(updated), xmlunescape(summary), e_categories))

    return elist  

def parse2(xmlSource):  
    try:

        encoding = re.findall( "<\?xml version=\"[^\"]*\" encoding=\"([^\"]*)\"\?>", xmlSource )[ 0 ]
    except: return None
    elist=listentries()
    # gather all list entries 
    entriesSrc = re.findall( "<slot[^>]*>(.*?)</slot>", xmlSource, re.DOTALL)
    datematch = re.compile(':\s+([0-9]+)/([0-9]+)/([0-9]{4})')
    i=1
    # enumerate thru the element list and gather info
    for entrySrc in entriesSrc:
        entry={}
	
        try:
		title   = str(i).zfill(2) + ": " + re.findall( "<discipline[^>]* name=\"(.*?)\"", entrySrc, re.DOTALL )[0]

		title	= title + " - " + re.findall( "<title>(.*?)</title>", entrySrc, re.DOTALL )[0]
	except:
		title   = str(i).zfill(2) + ": " +re.findall( "<title>(.*?)</title>", entrySrc, re.DOTALL )[0]
        try:

		id      = re.findall( "<versionPid>(.*?)</versionPid>", entrySrc, re.DOTALL )[0]
	except:
		channelname=title.split(":")
		if channelname[1]==" BBC One":		
			id = "bbc_one_london"
		elif channelname[1]==" BBC Two":
			id = "bbc_two_england"
		else: id = "bbc_three"
	opid = re.findall( "<pid>(.*?)</pid>", entrySrc, re.DOTALL )[0]
        updated = re.findall( "<scheduleStart>(.*?)</scheduleStart>", entrySrc, re.DOTALL )[0]
        summary = re.findall( "<shortSynopsis>(.*?)</shortSynopsis>", entrySrc, re.DOTALL )[0]
        try:
		categories = re.findall( "<live>(.*?)</live>", entrySrc, re.DOTALL )[0]
	except: categories = "true"
	match = datematch.search(title)
        if match:

            # if the title contains a data at the end use that as the updated date YYYY-MM-DD
            updated = "%s-%s-%s" % ( match.group(3), match.group(2), match.group(1)  )
        if categories == "true":
		i += 1      
		elist.entries.append(listentry(xmlunescape(title), xmlunescape(id), xmlunescape(updated), xmlunescape(summary), ["Sport"], opid))

    return elist  
